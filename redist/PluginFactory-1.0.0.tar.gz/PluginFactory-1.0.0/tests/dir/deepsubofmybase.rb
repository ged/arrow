require 'subofmybase'

class DeepSubOf < SubOfMyBase; end

#!/usr/bin/env ruby

require 'mybase'

class SubOfMyBase < MyBase; end

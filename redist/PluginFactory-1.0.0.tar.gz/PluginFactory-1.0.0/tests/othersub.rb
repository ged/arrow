#!/usr/bin/env ruby

require 'mybase'

class OtherSubMyBase < MyBase; end
